# kitware
### Groupware

참여자 : 5명
개발기간 :4주

### 개발 기술
Java, Servlet, JSP, JQuery, Ajax, JSON, JavaScript, CSS3, HTML5

### DBMS
Oracle 11g

### Was
Apache Tomcat 8.5

### IDE
Eclipse Java EE IDE WebDeveloper(Oxyzen)

### Design Pattern
MVC model 2, Singleton Pattern
