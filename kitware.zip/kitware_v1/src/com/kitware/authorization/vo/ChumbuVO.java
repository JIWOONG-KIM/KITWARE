package com.kitware.authorization.vo;

public class ChumbuVO {

}
